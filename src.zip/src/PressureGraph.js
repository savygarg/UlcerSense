import React, { useState } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";

/** Legacy chart shell — no simulated data; wire to backend if used again. */
function PressureGraph() {
  const [data] = useState([]);

  return (
    <div className="graph-card">
      <h2>Pressure Heat Trend</h2>
      <ResponsiveContainer width="100%" height={250}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#1e3a4f" />
          <XAxis dataKey="time" stroke="#7dd3fc" />
          <YAxis stroke="#7dd3fc" />
          <Tooltip />
          <Line type="monotone" dataKey="pressure" stroke="#00ffff" strokeWidth={3} dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export default PressureGraph;
