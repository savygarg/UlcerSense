
function SensorCard({ title, value, unit }) {
  return (
    <div className="sensor-card">
      <h3>{title}</h3>

      <div className="sensor-value">
        {Number(value).toFixed(1)}
        <span>{unit}</span>
      </div>
    </div>
  );
}

export default SensorCard;

