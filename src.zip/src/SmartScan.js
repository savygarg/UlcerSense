
import React, { useState } from "react";
import { motion } from "framer-motion";

function SmartScan({ data }) {
  const [scanning, setScanning] = useState(false);

  const startScan = () => {
    setScanning(true);

    setTimeout(() => {
      setScanning(false);
    }, 6000);
  };

  return (
    <div className="scan-container">
      <div className="scan-header">
        <h2>AI Pressure Scan</h2>

        <button onClick={startScan}>
          {scanning ? "Scanning..." : "Start Scan"}
        </button>
      </div>

      <div className="mattress-area">

        <motion.div
          className="mattress"
          animate={{
            boxShadow: scanning
              ? "0 0 40px rgba(0,255,255,0.7)"
              : "0 0 10px rgba(0,255,255,0.2)"
          }}
        />

        <motion.div
          className="elbow"
          animate={{
            scale: scanning ? 1.03 : 1
          }}
        />

        {scanning && (
          <motion.div
            className="scan-line"
            initial={{ y: -150 }}
            animate={{ y: 150 }}
            transition={{
              repeat: Infinity,
              duration: 2
            }}
          />
        )}

        {scanning && (
          <>
            <div className="heat-zone zone1" />
            <div className="heat-zone zone2" />
          </>
        )}
      </div>

      <div className="live-stats">
        <p>Pressure: {data?.raw?.fsr1}</p>
        <p>Temperature: {data?.raw?.temp}</p>
        <p>SpO2: {data?.raw?.spo2}</p>
      </div>
    </div>
  );
}

export default SmartScan;

