import React, { useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Activity,
  Thermometer,
  HeartPulse,
  ShieldAlert,
  Siren,
  Bed,
  ShieldCheck,
  Brain,
  CircleDot,
} from "lucide-react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from "recharts";
import SmartMattressVisualization from "./SmartMattressVisualization";
import { getRecommendationsForRisk } from "./utils/recommendations";

const DASH = "--";
const SENSOR_STATUS = { ACTIVE: "ACTIVE", INACTIVE: "INACTIVE", ERROR: "ERROR" };

const MAX_CHART_POINTS = 60;

const riskLevelTextClass = (level) => {
  if (!level || level === "NONE" || level === DASH) return "text-pal-mauve";
  if (level === "HIGH") return "text-red-300";
  if (level === "MEDIUM") return "text-orange-300";
  if (level === "LOW") return "text-emerald-300";
  return "text-pal-mauve";
};

const riskLevelPillClass = (level) => {
  if (!level || level === "NONE" || level === DASH) return "border-pal-mauve/35 bg-pal-navy/40 text-pal-mauve";
  if (level === "HIGH") return "border-red-400/45 bg-red-500/15 text-red-300";
  if (level === "MEDIUM") return "border-orange-400/45 bg-orange-500/15 text-orange-300";
  if (level === "LOW") return "border-emerald-400/45 bg-emerald-500/15 text-emerald-300";
  return "border-pal-mauve/35 bg-pal-navy/40 text-pal-mauve";
};

const navBadgeClass = (connectionLost, isInactive, isActive) => {
  if (connectionLost) return "border-orange-400/45 bg-orange-500/15 text-orange-200";
  if (isInactive) return "border-pal-mauve/45 bg-pal-navy/55 text-pal-mauve";
  if (isActive) return "border-emerald-400/45 bg-emerald-500/15 text-emerald-200";
  return "border-pal-mauve/50 bg-pal-navy/55 text-pal-cream";
};

function App() {
  const [sensorData, setSensorData] = useState(null);
  const [connectionLost, setConnectionLost] = useState(false);

  useEffect(() => {
    const fetchSensorData = async () => {
      try {
        const response = await fetch("http://127.0.0.1:5000/sensor-data");
        if (!response.ok) {
          throw new Error(`HTTP ${response.status}`);
        }
        const data = await response.json();

        console.log("BACKEND DATA:", data);

        setSensorData(data);
        setConnectionLost(false);
      } catch (err) {
        console.error(err);
        setConnectionLost(true);
      }
    };

    fetchSensorData();
    const id = setInterval(fetchSensorData, 1000);
    return () => clearInterval(id);
  }, []);

  const hasFirstSuccess = sensorData != null;

  const statusNorm = String(sensorData?.status ?? "")
    .trim()
    .toUpperCase();
  const isActive = statusNorm === SENSOR_STATUS.ACTIVE && !connectionLost;
  const isInactive = statusNorm === SENSOR_STATUS.INACTIVE;
  const showLiveMetrics = statusNorm === SENSOR_STATUS.ACTIVE;

  const [flowLine, setFlowLine] = useState("Waiting for sensor connection...");
  const prevStatusRef = useRef(null);
  const patientFlashTimerRef = useRef(null);
  const wasConnectionLostRef = useRef(false);

  useEffect(() => {
    if (patientFlashTimerRef.current) {
      clearTimeout(patientFlashTimerRef.current);
      patientFlashTimerRef.current = null;
    }

    if (connectionLost) {
      wasConnectionLostRef.current = true;
      setFlowLine("Sensor connection lost. Reconnecting...");
      return;
    }

    if (wasConnectionLostRef.current && hasFirstSuccess) {
      wasConnectionLostRef.current = false;
      if (statusNorm === SENSOR_STATUS.ACTIVE) {
        setFlowLine("Monitoring Active");
        prevStatusRef.current = SENSOR_STATUS.ACTIVE;
        return;
      }
      if (statusNorm === SENSOR_STATUS.INACTIVE) {
        setFlowLine("No Patient Detected");
        prevStatusRef.current = SENSOR_STATUS.INACTIVE;
        return;
      }
    }

    if (!hasFirstSuccess) {
      setFlowLine("Waiting for sensor connection...");
      prevStatusRef.current = null;
      return;
    }

    if (statusNorm === SENSOR_STATUS.INACTIVE) {
      setFlowLine("No Patient Detected");
      prevStatusRef.current = SENSOR_STATUS.INACTIVE;
      return;
    }

    if (statusNorm === SENSOR_STATUS.ACTIVE) {
      const edge = prevStatusRef.current !== SENSOR_STATUS.ACTIVE;
      prevStatusRef.current = SENSOR_STATUS.ACTIVE;
      if (edge) {
        setFlowLine("Patient detected");
        patientFlashTimerRef.current = setTimeout(() => {
          setFlowLine("Monitoring Active");
          patientFlashTimerRef.current = null;
        }, 1200);
      }
      return;
    }

    prevStatusRef.current = statusNorm || null;
  }, [statusNorm, hasFirstSuccess, connectionLost]);

  const pressureStr = showLiveMetrics ? String(sensorData?.pressure ?? DASH) : DASH;
  const tempStr = showLiveMetrics ? String(sensorData?.temperature ?? DASH) : DASH;
  const spo2Str = showLiveMetrics ? String(sensorData?.spo2 ?? DASH) : DASH;
  const fsr1Str = showLiveMetrics ? String(sensorData?.fsr1 ?? DASH) : DASH;
  const fsr2Str = showLiveMetrics ? String(sensorData?.fsr2 ?? DASH) : DASH;
  const rawRisk = sensorData?.risk_level;
  const riskScalar = Array.isArray(rawRisk) ? rawRisk[0] : rawRisk;
  const riskLevelStr =
    isInactive && hasFirstSuccess
      ? DASH
      : showLiveMetrics && riskScalar != null && riskScalar !== ""
        ? String(riskScalar).trim().toUpperCase()
        : DASH;
  const riskLevelDisplay =
    !hasFirstSuccess ? "Waiting..." : isInactive ? DASH : riskLevelStr === DASH ? "Waiting..." : riskLevelStr;

  const recommendations = useMemo(() => {
    if (!showLiveMetrics || riskScalar == null || riskScalar === "") return [];
    return getRecommendationsForRisk(riskScalar);
  }, [showLiveMetrics, riskScalar]);

  const chartTickRef = useRef(0);
  const [pressureSeries, setPressureSeries] = useState([]);
  const [spo2Series, setSpo2Series] = useState([]);

  useEffect(() => {
    if (!showLiveMetrics || sensorData == null || connectionLost) return;
    const p = Number(sensorData.pressure);
    const s = Number(sensorData.spo2);
    if (!Number.isFinite(p) || !Number.isFinite(s)) return;
    chartTickRef.current += 1;
    const t = chartTickRef.current;
    setPressureSeries((prev) => [...prev.slice(-(MAX_CHART_POINTS - 1)), { t, value: p }]);
    setSpo2Series((prev) => [...prev.slice(-(MAX_CHART_POINTS - 1)), { t, value: s }]);
  }, [showLiveMetrics, connectionLost, sensorData]);

  const [alerts, setAlerts] = useState([]);
  const prevRiskRef = useRef(null);

  useEffect(() => {
    if (!showLiveMetrics || riskScalar == null) return;
    const r = String(riskScalar).toUpperCase();
    if (r === "HIGH" && prevRiskRef.current !== "HIGH") {
      const now = new Date().toTimeString().slice(0, 8);
      setAlerts((prev) => [
        {
          time: now,
          zone: "System",
          message: "AI risk level elevated to HIGH — immediate clinical review advised.",
          level: "HIGH",
        },
        ...prev.slice(0, 12),
      ]);
    }
    prevRiskRef.current = r;
  }, [showLiveMetrics, riskScalar]);

  const operationalHint = useMemo(() => {
    if (connectionLost) return "Retrying backend connection; last readings may be shown.";
    if (!hasFirstSuccess) return "Polling ESP32 gateway every second.";
    if (isInactive) return "Place load on sensors to begin active monitoring.";
    if (showLiveMetrics) return "Streaming vitals from UlcerSense edge module.";
    return "";
  }, [connectionLost, hasFirstSuccess, isInactive, showLiveMetrics]);

  const metricCards = useMemo(
    () => [
      { title: "Pressure", value: pressureStr, unit: pressureStr === DASH ? "" : "kPa", icon: Activity, color: "text-pal-slate" },
      { title: "Temperature", value: tempStr, unit: tempStr === DASH ? "" : "°C", icon: Thermometer, color: "text-pal-mauve" },
      { title: "SpO2", value: spo2Str, unit: spo2Str === DASH ? "" : "%", icon: HeartPulse, color: "text-pal-cream" },
      { title: "FSR1", value: fsr1Str, unit: "", icon: CircleDot, color: "text-pal-slate" },
      { title: "FSR2", value: fsr2Str, unit: "", icon: CircleDot, color: "text-pal-mauve" },
      {
        title: "Risk Level",
        value: riskLevelDisplay,
        unit: "",
        icon: ShieldAlert,
        color: riskLevelTextClass(
          riskLevelStr === DASH || riskLevelDisplay === "Waiting..." ? null : riskLevelStr
        ),
        valueClass: riskLevelTextClass(
          riskLevelStr === DASH || riskLevelDisplay === "Waiting..." ? null : riskLevelStr
        ),
      },
    ],
    [pressureStr, tempStr, spo2Str, fsr1Str, fsr2Str, riskLevelStr, riskLevelDisplay]
  );

  const highPressureIndicator = showLiveMetrics && Number(sensorData?.pressure) > 800;

  const statusPillText = connectionLost
    ? "Reconnecting"
    : isInactive
      ? "No Patient"
      : isActive
        ? "Live Monitoring"
        : "Standby";

  return (
    <div className="mx-auto flex min-h-screen max-w-[1600px] flex-col gap-10 bg-transparent px-5 py-10 text-base text-pal-cream md:px-8 md:py-12 lg:px-12">
      <nav className="glass flex flex-wrap items-center justify-between gap-6 rounded-2xl px-7 py-6 md:px-8 md:py-7">
        <div className="flex items-center gap-4">
          <div className="rounded-xl border border-pal-mauve/25 bg-pal-navy/50 p-3 shadow-[0_0_20px_rgba(0,168,232,0.35)]">
            <Bed className="h-7 w-7 text-pal-cream" />
          </div>
          <div>
            <p className="text-sm font-medium uppercase tracking-[0.2em] text-pal-mauve md:text-[15px]">
              Smart Mattress Pressure Ulcer Prevention System
            </p>
            <h1 className="mt-1 text-xl font-semibold leading-snug text-pal-cream md:text-2xl">
              Ulcer Sense
            </h1>
          </div>
        </div>
        <div className="mt-1 flex flex-wrap items-center gap-3 md:mt-0">
          <a
            href="https://6a03f804efabc778565fdf12--polite-zabaione-5e1253.netlify.app/"
            target="_blank"
            rel="noreferrer"
            className="rounded-full border border-pal-mauve/30 bg-pal-navy/60 px-4 py-2 text-sm font-medium text-pal-cream transition hover:border-pal-cream hover:bg-pal-cream/10"
          >
            Open deployed app
          </a>
          <span
            className={`rounded-full border px-4 py-1.5 text-sm ${navBadgeClass(connectionLost, isInactive, isActive)}`}
          >
            {statusPillText}
          </span>
        </div>
      </nav>

      <section className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        <motion.div
          className="glass rounded-2xl p-6 sm:col-span-2 lg:col-span-3 xl:col-span-4 md:p-7"
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <div className="mb-4 flex items-center justify-between">
            <p className="text-sm font-medium text-pal-mauve md:text-[15px]">System status</p>
            <Brain className="h-5 w-5 text-pal-mauve" />
          </div>
          <p className="text-[15px] font-semibold leading-snug text-pal-cream md:text-lg">{flowLine}</p>
          <p className="mt-3 text-sm leading-relaxed text-pal-mauve/90 md:text-[15px]">{operationalHint}</p>
        </motion.div>

        {metricCards.map((card) => (
          <motion.div
            key={card.title}
            className="glass card-hover rounded-2xl p-6 md:p-7"
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.35 }}
          >
            <div className="mb-4 flex items-center justify-between">
              <p className="text-sm font-medium text-pal-mauve md:text-[15px]">{card.title}</p>
              <card.icon className={`h-5 w-5 ${card.color}`} />
            </div>
            <div className="flex items-end gap-2">
              <p className={`text-3xl font-semibold tracking-tight ${card.valueClass ?? "text-pal-cream"}`}>
                {card.value}
              </p>
              {card.unit ? <p className="pb-1 text-sm text-pal-mauve/90 md:text-[15px]">{card.unit}</p> : null}
            </div>
          </motion.div>
        ))}
      </section>

      <section className="grid grid-cols-1 gap-6 xl:grid-cols-3">
        <div className="glass relative overflow-hidden rounded-2xl p-6 md:p-7 xl:col-span-2">
          <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
            <h2 className="text-xl font-semibold text-pal-cream md:text-[1.35rem]">Smart Mattress Visualization</h2>
            <span className="rounded-full border border-pal-mauve/35 bg-pal-navy/45 px-4 py-1.5 text-sm text-pal-mauve">
              {flowLine}
            </span>
          </div>

          <SmartMattressVisualization
            isLiveMonitoring={isActive}
            highPressureIndicator={highPressureIndicator}
            spo2={showLiveMetrics ? Number(sensorData?.spo2) : null}
          />
        </div>

        <div className="glass rounded-2xl p-6 md:p-7">
          <div className="mb-5 flex items-center gap-3">
            <Brain className="h-6 w-6 text-pal-mauve" />
            <h2 className="text-xl font-semibold text-pal-cream md:text-[1.35rem]">Risk Prediction Panel</h2>
          </div>

          <div className="mb-6 flex items-center gap-5 rounded-2xl border border-pal-mauve/25 bg-pal-ink/40 p-5 md:p-6">
            <div className="relative h-24 w-24">
              <svg viewBox="0 0 120 120" className="h-full w-full -rotate-90">
                <circle cx="60" cy="60" r="52" stroke="rgba(0,126,167,0.45)" strokeWidth="10" fill="none" />
                {isActive ? (
                  <motion.circle
                    cx="60"
                    cy="60"
                    r="52"
                    stroke="url(#scanRingGradient)"
                    strokeWidth="10"
                    strokeLinecap="round"
                    fill="none"
                    strokeDasharray={327}
                    initial={{ strokeDashoffset: 327 }}
                    animate={{ strokeDashoffset: [280, 220, 280] }}
                    transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                  />
                ) : null}
                <defs>
                  <linearGradient id="scanRingGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#007ea7" />
                    <stop offset="100%" stopColor="#ffffff" />
                  </linearGradient>
                </defs>
              </svg>
              <div className="absolute inset-0 flex items-center justify-center text-center text-lg font-semibold leading-tight text-pal-cream">
                {isActive ? "LIVE" : isInactive ? "IDLE" : connectionLost ? "…" : "—"}
              </div>
            </div>
            <div className="space-y-1">
              <p className="text-sm font-medium text-pal-mauve md:text-[15px]">AI risk (backend)</p>
              <p className={`text-3xl font-semibold ${riskLevelTextClass(
                riskLevelDisplay === "Waiting..." || riskLevelDisplay === DASH ? null : riskLevelStr
              )}`}>
                {riskLevelDisplay}
              </p>
              <p className="text-sm text-pal-mauve/85 md:text-[15px]">
                {showLiveMetrics ? "Model output from Flask / ESP32 stream." : "No simulated risk scores."}
              </p>
            </div>
          </div>

          <AnimatePresence>
            {showLiveMetrics && riskLevelStr !== DASH ? (
              <motion.div
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-5 rounded-xl border border-pal-mauve/30 bg-pal-slate/25 p-5"
              >
                <div className="mb-3 flex items-center gap-2">
                  <ShieldCheck className="h-5 w-5 text-pal-cream" />
                  <p className="text-[15px] font-semibold text-pal-cream md:text-base">
                    Risk classification:{" "}
                    <span className={riskLevelTextClass(riskLevelStr)}>{riskLevelStr}</span>
                  </p>
                </div>
                <p className="text-sm leading-relaxed text-pal-mauve md:text-[15px]">
                  Live AI assessment from the mattress sensor fusion pipeline.
                </p>
              </motion.div>
            ) : null}
          </AnimatePresence>

          <div className="rounded-xl border border-pal-mauve/25 bg-pal-ink/35 p-5 md:p-6">
            <h3 className="mb-3 text-[15px] font-semibold text-pal-cream">Recommendations</h3>
            {recommendations.length === 0 ? (
              <p className="text-sm text-pal-mauve/80 md:text-[15px]">—</p>
            ) : (
              <ul className="space-y-2 text-sm leading-relaxed text-pal-mauve md:text-[15px]">
                {recommendations.map((line) => (
                  <li key={line}>- {line}</li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </section>

      <section className="grid grid-cols-1 gap-6 xl:grid-cols-2">
        <div className="glass rounded-2xl p-6 md:p-7">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
            <h2 className="text-xl font-semibold text-pal-cream md:text-[1.35rem]">Pressure trend</h2>
            <span
              className={`rounded-full border px-3 py-1 text-xs font-medium md:text-sm ${riskLevelPillClass(
                riskLevelDisplay === "Waiting..." || riskLevelDisplay === DASH ? null : riskLevelStr
              )}`}
            >
              {riskLevelDisplay}
            </span>
          </div>
          <p className="mb-4 text-sm leading-relaxed text-pal-mauve/90 md:text-[15px]">
            Historical pressure from live polls (no random simulation).
          </p>
          <div className="relative h-64">
            {pressureSeries.length === 0 ? (
              <div className="flex h-full items-center justify-center text-sm text-pal-mauve/90">
                Waiting for live data...
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={pressureSeries}>
                  <defs>
                    <linearGradient id="pressureFill" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#00a8e8" stopOpacity={0.85} />
                      <stop offset="95%" stopColor="#007ea7" stopOpacity={0.06} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(0, 126, 167, 0.2)" />
                  <XAxis dataKey="t" tick={{ fill: "#007ea7", fontSize: 13 }} tickLine={false} />
                  <YAxis tick={{ fill: "#007ea7", fontSize: 13 }} tickLine={false} domain={["auto", "auto"]} />
                  <Tooltip
                    contentStyle={{
                      background: "#003459",
                      border: "1px solid #007ea7",
                      color: "#ffffff",
                      fontSize: "14px",
                      fontFamily: "Poppins, sans-serif",
                    }}
                  />
                  <Area type="monotone" dataKey="value" stroke="#00a8e8" fillOpacity={1} fill="url(#pressureFill)" />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        <div className="glass rounded-2xl p-6 md:p-7">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
            <h2 className="text-xl font-semibold text-pal-cream md:text-[1.35rem]">SpO₂ trend</h2>
            <span className="rounded-full border border-pal-mauve/30 bg-pal-slate/20 px-3 py-1 text-xs font-medium text-pal-mauve md:text-sm">
              Live feed
            </span>
          </div>
          <p className="mb-4 text-sm leading-relaxed text-pal-mauve/90 md:text-[15px]">
            Blood oxygen from backend stream (poll every 1s).
          </p>
          <div className="relative h-64">
            {spo2Series.length === 0 ? (
              <div className="flex h-full items-center justify-center text-sm text-pal-mauve/90">
                Waiting for live data...
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={spo2Series}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(0, 126, 167, 0.2)" />
                  <XAxis dataKey="t" tick={{ fill: "#007ea7", fontSize: 13 }} tickLine={false} />
                  <YAxis tick={{ fill: "#007ea7", fontSize: 13 }} tickLine={false} domain={[85, 100]} />
                  <Tooltip
                    contentStyle={{
                      background: "#003459",
                      border: "1px solid #007ea7",
                      color: "#ffffff",
                      fontSize: "14px",
                      fontFamily: "Poppins, sans-serif",
                    }}
                  />
                  <Line type="monotone" dataKey="value" stroke="#ffffff" strokeWidth={2.5} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
      </section>

      <section className="glass rounded-2xl p-6 md:p-7">
        <div className="mb-5 flex items-center gap-3">
          <Siren className="h-6 w-6 text-pal-mauve" />
          <h2 className="text-xl font-semibold text-pal-cream md:text-[1.35rem]">Recent alerts</h2>
        </div>
        <div className="overflow-x-auto">
          {alerts.length === 0 ? (
            <p className="text-sm text-pal-mauve/85 md:text-[15px]">No automated alerts yet.</p>
          ) : (
            <table className="w-full text-left text-sm md:text-[15px]">
              <thead className="text-pal-mauve">
                <tr className="border-b border-pal-slate/50">
                  <th className="px-4 py-3 font-semibold">Time</th>
                  <th className="px-4 py-3 font-semibold">Zone</th>
                  <th className="px-4 py-3 font-semibold">Message</th>
                  <th className="px-4 py-3 font-semibold">Severity</th>
                </tr>
              </thead>
              <tbody>
                {alerts.map((alert, idx) => (
                  <tr
                    key={`${alert.time}-${idx}`}
                    className="border-b border-pal-navy/60 transition hover:bg-pal-slate/10"
                  >
                    <td className="px-4 py-3 text-pal-mauve">{alert.time}</td>
                    <td className="px-4 py-3 text-pal-cream">{alert.zone}</td>
                    <td className="px-4 py-3 text-pal-cream/95">{alert.message}</td>
                    <td className="px-4 py-3">
                      <span
                        className={`rounded-full px-3 py-1 text-xs font-medium md:text-sm ${
                          alert.level === "HIGH"
                            ? "bg-red-500/20 text-red-300"
                            : alert.level === "MEDIUM"
                              ? "bg-orange-500/20 text-orange-300"
                              : "bg-emerald-500/20 text-emerald-300"
                        }`}
                      >
                        {alert.level}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </section>

      <footer className="pb-2 pt-4 text-center text-sm leading-relaxed text-pal-mauve/85 md:text-[15px]">
        @Ulcer Sense 2026 . Real-time pressure ulcer prevention monitoring for hospital care teams . All rights reserved
      </footer>
    </div>
  );
}

export default App;
