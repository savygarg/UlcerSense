import { useEffect, useRef, useState } from "react";
import { fetchSensorData } from "../api/sensorApi";
import { POLL_INTERVAL_MS, SENSOR_STATUS } from "../constants/monitoring";

/**
 * Polls Flask /sensor-data every `intervalMs` using useEffect + setInterval.
 * Does NOT abort in-flight requests when the next tick fires (serial backend
 * can take >1s); skips overlapping ticks instead.
 */
export function useSensorPolling(intervalMs = POLL_INTERVAL_MS) {
  const [snapshot, setSnapshot] = useState(null);
  const [hasFirstSuccess, setHasFirstSuccess] = useState(false);
  const [connectionLost, setConnectionLost] = useState(false);

  const inFlightRef = useRef(false);
  const mountedRef = useRef(false);
  const abortRef = useRef(null);

  useEffect(() => {
    mountedRef.current = true;

    const tick = async () => {
      if (!mountedRef.current) return;
      if (inFlightRef.current) return;

      inFlightRef.current = true;
      const controller = new AbortController();
      abortRef.current = controller;

      try {
        const json = await fetchSensorData(controller.signal);
        if (!mountedRef.current) return;

        const status = String(json?.status ?? "").toUpperCase();
        const normalized = { ...json, status };

        if (status === SENSOR_STATUS.ERROR) {
          setConnectionLost(true);
          return;
        }

        setConnectionLost(false);
        setHasFirstSuccess(true);
        setSnapshot(normalized);
      } catch (err) {
        if (!mountedRef.current || controller.signal.aborted) return;
        setConnectionLost(true);
      } finally {
        inFlightRef.current = false;
      }
    };

    void tick();
    const id = setInterval(() => {
      void tick();
    }, intervalMs);

    return () => {
      mountedRef.current = false;
      clearInterval(id);
      abortRef.current?.abort();
      abortRef.current = null;
      inFlightRef.current = false;
    };
  }, [intervalMs]);

  return {
    data: snapshot,
    hasFirstSuccess,
    connectionLost,
  };
}
