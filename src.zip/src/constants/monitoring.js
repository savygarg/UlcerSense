/** Backend sensor API (full URL to /sensor-data) */
const envBase =
  typeof process !== "undefined" && process.env.REACT_APP_API_BASE_URL != null
    ? String(process.env.REACT_APP_API_BASE_URL).trim()
    : "";
export const SENSOR_API_URL =
  envBase.length > 0
    ? `${envBase.replace(/\/$/, "")}/sensor-data`
    : "http://127.0.0.1:5000/sensor-data";

export const POLL_INTERVAL_MS = 1000;

export const DASH = "--";

export const SENSOR_STATUS = {
  ACTIVE: "ACTIVE",
  INACTIVE: "INACTIVE",
  ERROR: "ERROR",
};

