const { test, expect } = require('@agent');

test('hello world!', () => {
	expect(1 + 1).toBe(2);
});