import React, { useState } from "react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";

/** Legacy chart shell — no simulated data; wire to backend if used again. */
function SpO2Graph() {
  const [data] = useState([]);

  return (
    <div className="graph-card">
      <h2>SpO₂ Trend</h2>
      <ResponsiveContainer width="100%" height={250}>
        <AreaChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#1e3a4f" />
          <XAxis dataKey="time" stroke="#7dd3fc" />
          <YAxis stroke="#7dd3fc" domain={[90, 100]} />
          <Tooltip />
          <Area type="monotone" dataKey="spo2" stroke="#00ff99" fill="#00ff9955" strokeWidth={3} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

export default SpO2Graph;
