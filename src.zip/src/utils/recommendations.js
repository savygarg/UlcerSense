/**
 * Clinical-style copy from backend AI risk only (no simulated risk).
 * @param {string | null | undefined} riskLevel — LOW | MEDIUM | HIGH
 * @returns {string[]}
 */
export function getRecommendationsForRisk(riskLevel) {
  if (!riskLevel) return [];
  const level = String(riskLevel).toUpperCase();
  if (level === "HIGH") {
    return [
      "Urgent: reposition patient immediately to offload high-pressure zones.",
      "Notify care team; verify skin integrity and circulation.",
      "Reduce sustained pressure duration; consider support surface adjustment.",
    ];
  }
  if (level === "MEDIUM") {
    return [
      "Reposition patient within the next care round; monitor pressure hotspots.",
      "Continue SpO₂ and temperature surveillance per protocol.",
      "Document tissue perfusion and patient comfort.",
    ];
  }
  if (level === "LOW") {
    return [
      "Maintain current repositioning schedule.",
      "Continue routine smart-mattress monitoring.",
    ];
  }
  return [];
}
