function AlertsTable() {
  return (
    <div className="alerts-table">
      <h2>Recent Alerts</h2>

      <table>
        <thead>
          <tr>
            <th>Time</th>
            <th>Alert</th>
            <th>Status</th>
          </tr>
        </thead>

        <tbody>
          <tr>
            <td>12:41 PM</td>
            <td>High Pressure Detected</td>
            <td className="danger">ACTIVE</td>
          </tr>

          <tr>
            <td>12:35 PM</td>
            <td>Low SpO2 Warning</td>
            <td className="warning">MONITOR</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}

export default AlertsTable;