import React from "react";
import { AnimatePresence, motion } from "framer-motion";

const PRESSURE_ZONES = [
  { id: "heels", left: "74%", top: "32%", width: "6%", height: "16%", intensity: 0.9 },
  { id: "sacrum", left: "42%", top: "32%", width: "13%", height: "16%", intensity: 1.0 },
  { id: "shoulders", left: "24%", top: "32%", width: "14%", height: "16%", intensity: 0.7 },
  { id: "head", left: "18%", top: "32%", width: "10%", height: "16%", intensity: 0.7 },
];

/** Deterministic ECG-style path (no Math.random — stable across renders). */
function buildStaticEcgPath() {
  let d = "M0 60 ";
  let x = 0;
  for (let i = 0; i < 18; i++) {
    const spacing = 58 + (i % 4) * 4;
    const spike = i % 5 === 0 ? 28 : 14;
    d += `L${x + 8} 60 L${x + 14} 52 L${x + 20} 60 L${x + 24} 60 L${x + 28} ${60 - spike} L${x + 34} 88 L${x + 40} 60 Q${x + 48} 48 ${x + 56} 60 L${x + spacing} 60 `;
    x += spacing;
  }
  return d;
}

const STATIC_ECG_PATH = buildStaticEcgPath();

/**
 * @param {object} props
 * @param {boolean} props.isLiveMonitoring — true only when backend ACTIVE and connected
 * @param {boolean} props.highPressureIndicator — highlight when sustained load (from real pressure)
 * @param {number | null} props.spo2 — null shows "--"
 */
export default function SmartMattressVisualization({
  isLiveMonitoring = false,
  highPressureIndicator = false,
  spo2 = null,
}) {
  const spo2Label = spo2 == null || Number.isNaN(spo2) ? "--" : `${Math.round(spo2)}%`;

  const zonePulse = isLiveMonitoring && highPressureIndicator;

  return (
    <div className="relative mx-auto aspect-[2/1] w-full max-w-4xl overflow-hidden rounded-xl bg-pal-ink">
      <img
        src="/Bed.png"
        className="h-full w-full object-contain opacity-90"
        alt="Smart Mattress Wireframe"
      />

      {PRESSURE_ZONES.map((zone) => (
        <motion.div
          key={zone.id}
          className="absolute pointer-events-none"
          style={{
            left: zone.left,
            top: zone.top,
            width: zone.width,
            height: zone.height,
          }}
          animate={
            zonePulse
              ? {
                  opacity: [0.55, 0.92, 0.55],
                  scale: [0.98, 1.04, 0.98],
                }
              : { opacity: 0.18, scale: 1 }
          }
          transition={{
            duration: 3,
            repeat: zonePulse ? Infinity : 0,
            ease: "linear",
            delay: zone.intensity * 0.4,
          }}
        >
          <div
            className="absolute inset-[-60%] rounded-full opacity-40"
            style={{
              background: "radial-gradient(circle, rgba(0, 168, 232, 0.22) 0%, transparent 70%)",
              filter: "blur(20px)",
            }}
          />
          <div
            className="absolute inset-0 rounded-[40%] border border-pal-slate/25"
            style={{
              background:
                "radial-gradient(ellipse at center, rgba(0, 168, 232, 0.32) 0%, rgba(0, 126, 167, 0.12) 60%, transparent 100%)",
              filter: "blur(6px)",
            }}
          />
          <div
            className="absolute rounded-full"
            style={{
              width: "40%",
              height: "40%",
              left: "30%",
              top: "30%",
              background: "radial-gradient(circle, #ffffff 0%, rgba(0, 168, 232, 0.75) 40%, transparent 100%)",
              filter: "blur(4px)",
              boxShadow: "0 0 15px rgba(255, 255, 255, 0.4)",
            }}
          />
          <div
            className="absolute inset-0 opacity-30"
            style={{
              backgroundImage: "radial-gradient(circle, #00a8e8 1px, transparent 1px)",
              backgroundSize: "6px 6px",
            }}
          />
        </motion.div>
      ))}

      <AnimatePresence>
        {isLiveMonitoring && (
          <div className="pointer-events-none absolute inset-0">
            <motion.div
              className="absolute top-0 h-full w-[18%]"
              style={{
                background:
                  "linear-gradient(90deg, transparent 0%, rgba(0,168,232,0.1) 20%, rgba(0,168,232,0.42) 50%, rgba(0,168,232,0.1) 80%, transparent 100%)",
                filter: "blur(10px)",
                boxShadow: "0 0 50px rgba(0,168,232,0.32)",
              }}
              initial={{ left: "-20%" }}
              animate={{ left: "120%" }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "linear",
              }}
            />
            <div className="absolute bottom-4 left-4 rounded bg-pal-navy/80 px-3 py-1.5 text-sm font-medium tracking-wide text-pal-slate">
              SYSTEM SCAN: LIVE
            </div>
          </div>
        )}
      </AnimatePresence>

      <div className="absolute bottom-[22%] right-[6%] z-40 w-[138px] rounded-[16px] border border-pal-mauve/30 bg-pal-navy/95 p-3 shadow-[0_0_25px_rgba(0,168,232,0.15)] backdrop-blur-xl">
        <p className="mb-2 text-center text-[11px] font-semibold leading-tight tracking-[0.14em] text-pal-cream/90">
          HEALTH STATISTICS
        </p>

        <div className="relative h-14 w-full overflow-hidden rounded-md border border-pal-mauve/20 bg-pal-ink/80">
          <motion.svg
            viewBox="0 0 2000 100"
            preserveAspectRatio="none"
            className="absolute inset-0 h-full w-[400%]"
            animate={isLiveMonitoring ? { x: ["0%", "-50%"] } : { x: "0%" }}
            transition={{
              duration: isLiveMonitoring ? 20 : 0,
              repeat: isLiveMonitoring ? Infinity : 0,
              ease: "linear",
            }}
          >
            <path
              d={STATIC_ECG_PATH}
              fill="none"
              stroke="#00a8e8"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
              style={{ filter: "drop-shadow(0 0 4px rgba(0,168,232,0.65))" }}
            />
            <path
              d={STATIC_ECG_PATH}
              fill="none"
              stroke="#00a8e8"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
              transform="translate(2000, 0)"
              style={{ filter: "drop-shadow(0 0 4px rgba(0,168,232,0.65))" }}
            />
          </motion.svg>
          <div
            className="pointer-events-none absolute inset-0 opacity-[0.07]"
            style={{
              backgroundImage:
                "linear-gradient(#00a8e8 1px, transparent 1px), linear-gradient(90deg, #00a8e8 1px, transparent 1px)",
              backgroundSize: "15px 15px",
            }}
          />
        </div>

        <div className="mt-3 flex items-center justify-between gap-3 text-pal-cream">
          <div className="flex items-center gap-1.5">
            <span className="text-sm text-pal-slate">♥</span>
            <div>
              <p className="text-[11px] font-medium uppercase tracking-wide text-pal-mauve/85">BPM</p>
              <p className="text-base font-medium leading-none">--</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-[11px] font-medium uppercase tracking-wide text-pal-mauve/85">SpO₂</p>
            <p className="text-base font-medium leading-none">{spo2Label}</p>
          </div>
        </div>
      </div>

      <div className="absolute right-4 top-4 flex items-center gap-2">
        <div
          className={`h-2 w-2 rounded-full ${
            isLiveMonitoring && highPressureIndicator
              ? "animate-pulse bg-red-500"
              : isLiveMonitoring
                ? "bg-emerald-400"
                : "bg-pal-mauve/50"
          }`}
        />
        <span className="text-xs font-medium uppercase tracking-widest text-pal-mauve/90 md:text-sm">
          {isLiveMonitoring ? "Pressure Monitor Active" : "Monitoring Idle"}
        </span>
      </div>
    </div>
  );
}
