import { SENSOR_API_URL } from "../constants/monitoring";

/**
 * Fetches one reading from Flask. Throws on network / HTTP errors.
 * Caller interprets JSON.status (ACTIVE | INACTIVE | ERROR).
 */
export async function fetchSensorData(signal) {
  const response = await fetch(SENSOR_API_URL, {
    method: "GET",
    signal,
    headers: { Accept: "application/json" },
  });

  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }

  const data = await response.json();
  // Debug: verify live payloads in DevTools console
  console.log("[sensor-data] response:", data);

  const status =
    data && typeof data === "object" && data.status != null
      ? String(data.status).trim().toUpperCase()
      : data?.status;
  return { ...data, status };
}
