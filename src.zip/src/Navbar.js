
function Navbar() {
  return (
    <div className="navbar">
      <h1>🛏️ Smart Mattress AI Dashboard</h1>

      <div className="nav-status">
        <span className="status-dot"></span>
        Live Monitoring Active
      </div>
    </div>
  );
}

export default Navbar;

