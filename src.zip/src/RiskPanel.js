function RiskPanel({ risk }) {

  const getColor = () => {
    if (risk === "HIGH") return "#ff3b3b";
    if (risk === "MEDIUM") return "#ffb347";
    return "#4dff88";
  };

  return (
    <div
      className="risk-panel"
      style={{
        borderColor: getColor(),
        boxShadow: `0 0 20px ${getColor()}55`
      }}
    >
      <h2>AI Risk Prediction</h2>

      <div
        className="risk-value"
        style={{
          color: getColor()
        }}
      >
        {risk}
      </div>

      <div className="risk-recommendation">
        {risk === "HIGH" &&
          "⚠ Immediate reposition recommended"}

        {risk === "MEDIUM" &&
          "Monitor pressure duration"}

        {risk === "LOW" &&
          "Patient stable"}
      </div>
    </div>
  );
}

export default RiskPanel;